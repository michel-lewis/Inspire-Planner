import { LightningElement } from 'lwc';

export default class ResourceAllocationNavigationBar extends LightningElement {}