import { LightningElement } from 'lwc';

export default class MainScreen extends LightningElement {}