import { LightningElement } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';

export default class MenuPrincipal extends LightningElement {
    collaborationIsVisible = false;

    listCollaborator(event){
        event.preventDefault();  
        //console.log(collaborationIsVisible);
        this.collaborationIsVisible = true;
    }
    
       
}