import { LightningElement } from 'lwc';

export default class NewBaseLine extends LightningElement {}