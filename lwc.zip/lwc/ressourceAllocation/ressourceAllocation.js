import { LightningElement } from 'lwc';

export default class RessourceAllocation extends LightningElement {}