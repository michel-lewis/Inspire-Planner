import { LightningElement } from 'lwc';

export default class Upload_file extends LightningElement {}