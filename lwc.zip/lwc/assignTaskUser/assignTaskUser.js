import { LightningElement } from 'lwc';

export default class SsigneTaskUser extends LightningElement {}