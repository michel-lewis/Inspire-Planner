import { LightningElement } from 'lwc';
//import fetchDataHelper from './fetchDataHelper';

const columns = [
    { label:'', fieldName: '',        
      cellAttributes: {
            iconName: { fieldName: 'trendIcon' },
            iconPosition: 'right',
        }
    }, 
    { label: '', fieldName: '',        
      cellAttributes: {
            iconName: { fieldName: 'trendIcon1' },
            iconPosition: 'right',
        }
    },     
    { label: 'Task Subject', fieldName: 'name', editable: true, initialWidth:300 },
    { label: 'Subject', fieldName: 'website', type: 'url', type: 'text', initialWidth:100 },
    { label: '% Complete', fieldName: 'phone', type: 'phone', initialWidth:100 },
    { label: 'Duration', fieldName: 'amount', type: 'currency', initialWidth:100 },
    { label: 'Start Date', fieldName: 'closeAt', type: 'date', initialWidth:100 },
];

const data = [
    {
    trendIcon: 'utility:link', 
    trendIcon1: 'utility:comments',          
    name: 'ONE Onboarding Project',
    website: 'Not Started',
    amount: '1 day',
    phone: 0,
    closeAt: "06/04/2019"
    },
    {
    trendIcon: 'utility:link',     
    trendIcon1: 'utility:comments',   
    name: ' ',
    website: ' ',
    amount: ' ',
    phone: 0,
    closeAt: " "
    },
    {
    trendIcon: 'utility:link',
    trendIcon1: 'utility:comments',     
    name: ' ',
    website: ' ',
    amount: ' ',
    phone: 0,
    closeAt: " "
   },
     {
    trendIcon: 'utility:link',
    trendIcon1: 'utility:comments',        
    name: ' ',
    website: ' ',
    amount: ' ',
    phone: 0,
    closeAt: " "
    },
    {
    trendIcon: 'utility:link',
    trendIcon1: 'utility:comments',          
    name: ' ',
    website: ' ',
    amount: ' ',
    phone: 0,
    closeAt: " "
   } 

];

export default class App extends LightningElement {
    data = data //[];
    columns = columns;
}