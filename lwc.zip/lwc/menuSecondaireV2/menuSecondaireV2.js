import { LightningElement } from 'lwc';

export default class MenuSecondaireV2 extends LightningElement {}