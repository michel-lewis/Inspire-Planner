import { LightningElement } from 'lwc';

export default class Chat extends LightningElement {
    
}