import { LightningElement } from 'lwc';

export default class Left_menu extends LightningElement {}